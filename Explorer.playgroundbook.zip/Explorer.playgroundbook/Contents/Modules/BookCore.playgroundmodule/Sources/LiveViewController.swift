//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  A source file which is part of the auxiliary module named "BookCore".
//  Provides the implementation of the "always-on" live view.
//

import UIKit
import PlaygroundSupport
import SceneKit
import os

@objc(BookCore_LiveViewController)
public class LiveViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    let collisionMap: [[Bool]] = [
        [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true],
        [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true],
        [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, false, false, false, false, false, true, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, false, false, false, false, false, false, false, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, false, false, false, false, false, false, false, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, false, false, false, false, false, false, false, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, true, true, true, true, true, true, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, true, true, true, true, true, true, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, true, true, true, true, true, true, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, false, false, true, true]]
    
    var scnScene: SCNScene!
    
    var scnView: SCNView!
    
    var cameraNode: SCNNode!
    
    var moveButton: UIButton!
    
    var turnLeadingButton: UIButton!
    
    var promptView: TKRobotPromptView!
    
    public override func loadView() {
        super.loadView()
        
        setUpScene()
        setUpMoveButton()
        setUpTurnLeadingButton()
        setUpPrompt()
    }
    
    func setUpScene() {
        
        scnScene = SCNScene(named: "PlayerMap.scn")!
        
        let scnView = SCNView()
        
        scnView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scnView)
        
        let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(pan(_:)))
        
        scnView.addGestureRecognizer(panGestureRecognizer)
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(tapped(_:)))
        scnView.addGestureRecognizer(tapGestureRecognizer)
        
        view.addConstraints([NSLayoutConstraint(item: scnView,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leading,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: scnView,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailing,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: scnView,
                                                attribute: .topMargin,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .topMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: scnView,
                                                attribute: .bottomMargin,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .bottomMargin,
                                                multiplier: 1,
                                                constant: 0)])
        
        self.scnView = scnView
    }
    
    func setUpMoveButton() {
        let moveButton = UIButton()
        
        moveButton.setImage(UIImage(systemName: "arrowtriangle.up.fill"), for: .normal)
        moveButton.translatesAutoresizingMaskIntoConstraints = false
        
        moveButton.addTarget(self, action: #selector(moveForward), for: .touchUpInside)
        
        moveButton.backgroundColor = .systemGray4
        moveButton.layer.cornerRadius = 32
        
        view.addSubview(moveButton)
        
        view.addConstraints([NSLayoutConstraint(item: moveButton,
                                                attribute: .centerX,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .centerXWithinMargins,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: moveButton,
                                                attribute: .bottom,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .bottomMargin,
                                                multiplier: 1,
                                                constant: -72),
                             NSLayoutConstraint(item: moveButton,
                                                attribute: .width,
                                                relatedBy: .equal,
                                                toItem: moveButton,
                                                attribute: .height,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: moveButton,
                                                attribute: .width,
                                                relatedBy: .equal,
                                                toItem: nil,
                                                attribute: .notAnAttribute,
                                                multiplier: 1,
                                                constant: 64)])
        
        self.moveButton = moveButton
    }
    
    func setUpTurnLeadingButton() {
        let turnLeadingButton = UIButton()
        let turnTrailingButton = UIButton()
        
        let stackView = UIStackView()
        
        turnLeadingButton.setImage(UIImage(systemName: "arrowtriangle.left.fill"), for: .normal)
        turnLeadingButton.translatesAutoresizingMaskIntoConstraints = false
        turnLeadingButton.backgroundColor = .systemGray4
        turnLeadingButton.layer.cornerRadius = 32
        turnLeadingButton.addTarget(self, action: #selector(turnLeading), for: .touchUpInside)
        
        turnTrailingButton.setImage(UIImage(systemName: "arrowtriangle.right.fill"), for: .normal)
        turnTrailingButton.translatesAutoresizingMaskIntoConstraints = false
        turnTrailingButton.backgroundColor = .systemGray4
        turnTrailingButton.layer.cornerRadius = 32
        turnTrailingButton.addTarget(self, action: #selector(turnTrailing), for: .touchUpInside)
        
//        turnLeadingButton.addTarget(self, action: #selector(moveForward), for: .touchUpInside)
        
        stackView.addArrangedSubview(turnLeadingButton)
        stackView.addArrangedSubview(turnTrailingButton)
        
        stackView.distribution = .fillEqually
        stackView.axis = .horizontal
        
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.spacing = 16
        
        view.addSubview(stackView)
        
        view.addConstraints([NSLayoutConstraint(item: stackView,
                                                attribute: .centerX,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .centerXWithinMargins,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: stackView,
                                                attribute: .width,
                                                relatedBy: .equal,
                                                toItem: stackView,
                                                attribute: .height,
                                                multiplier: 2,
                                                constant: 16),
                             NSLayoutConstraint(item: stackView,
                                                attribute: .bottom,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .bottomMargin,
                                                multiplier: 1,
                                                constant: -8),
                             NSLayoutConstraint(item: stackView,
                                                attribute: .height,
                                                relatedBy: .equal,
                                                toItem: nil,
                                                attribute: .notAnAttribute,
                                                multiplier: 1,
                                                constant: 64)])
    }
    
    @objc func pan(_ sender: UIPanGestureRecognizer) {
        let rotateAction = SCNAction.rotateBy(x: (sender.translation(in: sender.view!).y / sender.view!.bounds.height) * .pi,
                                              y: (sender.translation(in: sender.view!).x / sender.view!.bounds.width) * .pi,
                                              z: 0, duration: 0)
        
        sender.setTranslation(.zero, in: sender.view!)
        
        cameraNode.runAction(rotateAction)
    }
    
    @objc func tapped(_ sender: UITapGestureRecognizer) {
        let location = sender.location(in: scnView)
        let hits = self.scnView.hitTest(location, options: nil)
        
        if hits.filter({ $0.node.name == "chest" }).first != nil {
            PlaygroundPage.current.navigateTo(page: .next)
        }
    }
    
    @objc func turnLeading() {
        let rotateAction = SCNAction.rotateBy(x: 0,
                                              y: .pi / 180 * 15,
                                              z: 0, duration: 0.2)
        
        cameraNode.runAction(rotateAction)
    }
    
    @objc func turnTrailing() {
        let rotateAction = SCNAction.rotateBy(x: 0,
                                              y: -.pi / 180 * 15,
                                              z: 0, duration: 0.2)
        
        cameraNode.runAction(rotateAction)
    }
    
    @objc func moveForward() {
        
        var direction = Int(round((cameraNode.eulerAngles.y / .pi * 180) / 90)) % 4
        
        var possibleMovements = [SCNVector3(0, 0, -0.5), // 0º   (Forward)
                                 SCNVector3(-0.5, 0, 0), // 90º  (Left/Right)
                                 SCNVector3(0, 0, 0.5),  // 180º (Down)
                                 SCNVector3(0.5, 0, 0)]  // 270º (Left/Right)
        
        if direction < 0 {
            direction *= -1
            possibleMovements = [SCNVector3(0, 0, -0.5), // 0º   (Forward)
                                 SCNVector3(0.5, 0, 0), // 90º  (Left/Right)
                                 SCNVector3(0, 0, 0.5),  // 180º (Down)
                                 SCNVector3(-0.5, 0, 0)]  // 270º (Left/Right)
            
        }
        
        if direction > 3 { return }
        
        let movement = possibleMovements[direction]
        
        let moveAction = SCNAction.move(by: movement, duration: 0.2)
        
        moveAction.timingMode = .easeInEaseOut
        
        let newZ = Int(round((cameraNode.position.z + 4.75 + movement.z) / 0.5))
        let newX = Int(round((cameraNode.position.x + 4.75 + movement.x) / 0.5))
        
        if 0...19 ~= newZ && 0...19 ~= newX {
            let isWall = collisionMap.reversed()[newZ].reversed()[newX]
            
            if !isWall {
                cameraNode.runAction(moveAction)
            }
        }
    }
    
    func setUpPrompt() {
        let promptView = TKRobotPromptView(with: "Welcome to the dungeon. The guards accidentally left the door unlocked—oh what's in that chest ahead? Let's open it and find out.\nPan around the scene or use the control buttons below.", sender: self)
        
        promptView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(promptView)
        
        view.addConstraints([NSLayoutConstraint(item: promptView,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leadingMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: promptView,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailingMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: promptView,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .topMargin,
                                                multiplier: 1,
                                                constant: 16)])
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
    }
    
    func setupCamera() {
        scnView.autoenablesDefaultLighting = false
        cameraNode = SCNNode()
        let camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 2.75, y: 1.6, z: 2.75)

        scnView.defaultCameraController.interactionMode = .fly

        camera.zNear = 0
        camera.focalLength = 20
        
        cameraNode.camera = camera
        
        scnScene.rootNode.addChildNode(cameraNode)
        
        scnView.scene = scnScene
    }
    
    
    public func liveViewMessageConnectionOpened() {
        // Implement this method to be notified when the live view message connection is opened.
        // The connection will be opened when the process running Contents.swift starts running and listening for messages.
    }
    
    public func liveViewMessageConnectionClosed() {
        // Implement this method to be notified when the live view message connection is closed.
        // The connection will be closed when the process running Contents.swift exits and is no longer listening for messages.
        // This happens when the user's code naturally finishes running, if the user presses Stop, or if there is a crash.
    }
    
    public func receive(_ message: PlaygroundValue) {
        // Implement this method to receive messages sent from the process running Contents.swift.
        // This method is *required* by the PlaygroundLiveViewMessageHandler protocol.
        // Use this method to decode any messages sent as PlaygroundValue values and respond accordingly.
        switch message {
        case .string(let string):
            print(string)
        default:
            break
        }
        
    }
}
