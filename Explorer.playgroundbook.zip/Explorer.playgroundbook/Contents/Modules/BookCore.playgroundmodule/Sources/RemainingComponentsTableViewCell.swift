//
//  RemainingComponentsTableViewCell.swift
//  BookCore
//
//  Created by JiaChen(: on 10/4/21.
//

import UIKit

public class RemainingComponentsTableViewCell: UITableViewCell {

    let previewImageView = UIImageView()
    let promptLabel = UILabel()
    
    public var previewImage: UIImage? {
        didSet {
            previewImageView.image = previewImage
        }
    }
    
    public var isUsed: Bool = false {
        didSet {
            previewImageView.alpha = isUsed ? 0.3 : 1
            promptLabel.isHidden = !isUsed
        }
    }
    
    public override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
    
    func setUp() {
        
        guard previewImageView.superview == nil else { return }
        
        previewImageView.translatesAutoresizingMaskIntoConstraints = false
        
        previewImageView.contentMode = .scaleAspectFit
        
        contentView.addSubview(previewImageView)
        
        promptLabel.translatesAutoresizingMaskIntoConstraints = false
        
        promptLabel.text = "Used"
        
        promptLabel.textColor = .white
        
        promptLabel.font = UIFont.boldSystemFont(ofSize: 15)
        
        promptLabel.isHidden = true
        
        contentView.addSubview(promptLabel)
        
        contentView.addConstraints([NSLayoutConstraint(item: previewImageView,
                                                       attribute: .leading,
                                                       relatedBy: .equal,
                                                       toItem: contentView,
                                                       attribute: .leading,
                                                       multiplier: 1,
                                                       constant: 8),
                                    NSLayoutConstraint(item: previewImageView,
                                                       attribute: .trailing,
                                                       relatedBy: .equal,
                                                       toItem: contentView,
                                                       attribute: .trailing,
                                                       multiplier: 1,
                                                       constant: -8),
                                    NSLayoutConstraint(item: previewImageView,
                                                       attribute: .top,
                                                       relatedBy: .equal,
                                                       toItem: contentView,
                                                       attribute: .top,
                                                       multiplier: 1,
                                                       constant: 4),
                                    NSLayoutConstraint(item: previewImageView,
                                                       attribute: .bottom,
                                                       relatedBy: .equal,
                                                       toItem: contentView,
                                                       attribute: .bottom,
                                                       multiplier: 1,
                                                       constant: -4),
                                    NSLayoutConstraint(item: previewImageView,
                                                       attribute: .height,
                                                       relatedBy: .equal,
                                                       toItem: nil,
                                                       attribute: .notAnAttribute,
                                                       multiplier: 1,
                                                       constant: 150 - 8),
                                    NSLayoutConstraint(item: promptLabel,
                                                       attribute: .centerX,
                                                       relatedBy: .equal,
                                                       toItem: contentView,
                                                       attribute: .centerX,
                                                       multiplier: 1,
                                                       constant: 0),
                                    NSLayoutConstraint(item: promptLabel,
                                                       attribute: .centerY,
                                                       relatedBy: .equal,
                                                       toItem: contentView,
                                                       attribute: .centerY,
                                                       multiplier: 1,
                                                       constant: 0)])
    }

    public override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
