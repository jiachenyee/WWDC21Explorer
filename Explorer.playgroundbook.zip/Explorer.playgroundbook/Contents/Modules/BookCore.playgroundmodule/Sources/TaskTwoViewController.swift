//
//  TaskTwoViewController.swift
//  BookCore
//
//  Created by JiaChen(: on 9/4/21.
//

import UIKit
import SwiftUI
import PlaygroundSupport

public class TaskTwoViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    struct PieceOne: View {
        var body: some View {
            Image("01").resizable().aspectRatio(contentMode: .fit)
        }
    }
    struct PieceTwo: View {
        var body: some View {
            Image("02").resizable().aspectRatio(contentMode: .fit)
        }
    }
    struct PieceThree: View {
        var body: some View {
            Image("03").resizable().aspectRatio(contentMode: .fit)
        }
    }
    
    var taskTitleLabel: UILabel!
    var sceneDescriptionLabel: UILabel!
    var sceneNextButton: UIButton!
    var previewView: UIView!
    var targetView: UIView?
    
    var promptView: TKRobotPromptView!
    
    public var isCurrent = false
    
    var remainingComponentsTableView: UITableView!
    
    var didUseItem: [Bool] {
        let startIndex = PlaygroundPage.current.text.range(of: "//#-observe-1")?.lowerBound
        let endIndex = PlaygroundPage.current.text.range(of: "//#-end-observe-1")?.upperBound

        let text = String(PlaygroundPage.current.text[startIndex!...endIndex!])
        
        let pieceOne = text.contains("PieceOne()")
        let pieceTwo = text.contains("PieceTwo()")
        let pieceThree = text.contains("PieceThree()")
        
        return [pieceOne, pieceTwo, pieceThree]
    }
    
    public override func loadView() {
        super.loadView()
        let taskTitleLabel = UILabel()
        taskTitleLabel.text = isCurrent ? "🎉 You did it!" : "Piece the Document"
        taskTitleLabel.font = .systemFont(ofSize: 32, weight: .bold)
        taskTitleLabel.textAlignment = .center
        taskTitleLabel.textColor = .white
        
        taskTitleLabel.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(taskTitleLabel)
        
        view.addConstraints([NSLayoutConstraint(item: taskTitleLabel,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leadingMargin,
                                                multiplier: 1,
                                                constant: 16),
                             NSLayoutConstraint(item: taskTitleLabel,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailingMargin,
                                                multiplier: 1,
                                                constant: -16),
                             NSLayoutConstraint(item: taskTitleLabel,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .topMargin,
                                                multiplier: 1,
                                                constant: 16)])
        
//        let taskInstructionsLabel = UILabel()
//
//        taskInstructionsLabel.text = "You found a torn document in the chest. Using HStacks and VStacks, piece the document together."
//        taskInstructionsLabel.numberOfLines = 0
//        taskInstructionsLabel.textAlignment = .center
//
//        taskInstructionsLabel.translatesAutoresizingMaskIntoConstraints = false
//        taskInstructionsLabel.textColor = .white
//
//        view.addSubview(taskInstructionsLabel)
//
//        view.addConstraints([NSLayoutConstraint(item: taskInstructionsLabel,
//                                                attribute: .leading,
//                                                relatedBy: .equal,
//                                                toItem: view,
//                                                attribute: .leadingMargin,
//                                                multiplier: 1,
//                                                constant: 16),
//                             NSLayoutConstraint(item: taskInstructionsLabel,
//                                                attribute: .trailing,
//                                                relatedBy: .equal,
//                                                toItem: view,
//                                                attribute: .trailingMargin,
//                                                multiplier: 1,
//                                                constant: -16),
//                             NSLayoutConstraint(item: taskInstructionsLabel,
//                                                attribute: .bottom,
//                                                relatedBy: .equal,
//                                                toItem: view,
//                                                attribute: .bottomMargin,
//                                                multiplier: 1,
//                                                constant: -16)])
        
        
        let remainingComponentsTableView = UITableView()
        
        remainingComponentsTableView.register(RemainingComponentsTableViewCell.self, forCellReuseIdentifier: "cell")
        
        remainingComponentsTableView.translatesAutoresizingMaskIntoConstraints = false
        
        remainingComponentsTableView.delegate = self
        remainingComponentsTableView.dataSource = self
        
        remainingComponentsTableView.backgroundColor = .clear
        remainingComponentsTableView.separatorStyle = .none
        
        view.addSubview(remainingComponentsTableView)
        
        view.addConstraints([NSLayoutConstraint(item: remainingComponentsTableView,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leadingMargin,
                                                multiplier: 1,
                                                constant: 16),
                             NSLayoutConstraint(item: remainingComponentsTableView,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: taskTitleLabel,
                                                attribute: .bottom,
                                                multiplier: 1,
                                                constant: 32),
                             NSLayoutConstraint(item: remainingComponentsTableView,
                                                attribute: .bottom,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .bottomMargin,
                                                multiplier: 1,
                                                constant: -32),
                             NSLayoutConstraint(item: remainingComponentsTableView,
                                                attribute: .width,
                                                relatedBy: .equal,
                                                toItem: nil,
                                                attribute: .notAnAttribute,
                                                multiplier: 1,
                                                constant: 150)])
        
        setUpPrompt()
        
        let previewView = UIView()
        
        previewView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(previewView)
        
        view.addConstraints([NSLayoutConstraint(item: previewView,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: remainingComponentsTableView,
                                                attribute: .trailing,
                                                multiplier: 1,
                                                constant: 8),
                             NSLayoutConstraint(item: previewView,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: taskTitleLabel,
                                                attribute: .bottom,
                                                multiplier: 1,
                                                constant: 8),
                             NSLayoutConstraint(item: previewView,
                                                attribute: .bottom,
                                                relatedBy: .equal,
                                                toItem: promptView,
                                                attribute: .top,
                                                multiplier: 1,
                                                constant: -8),
                             NSLayoutConstraint(item: previewView,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailing,
                                                multiplier: 1,
                                                constant: -16)])
        
        
        if let targetView = targetView {
            previewView.addSubview(targetView)
            
            view.addConstraints([NSLayoutConstraint(item: targetView,
                                                    attribute: .leading,
                                                    relatedBy: .greaterThanOrEqual,
                                                    toItem: previewView,
                                                    attribute: .leading,
                                                    multiplier: 1,
                                                    constant: 0),
                                 NSLayoutConstraint(item: targetView,
                                                    attribute: .centerX,
                                                    relatedBy: .equal,
                                                    toItem: previewView,
                                                    attribute: .centerX,
                                                    multiplier: 1,
                                                    constant: 0),
                                 NSLayoutConstraint(item: targetView,
                                                    attribute: .top,
                                                    relatedBy: .greaterThanOrEqual,
                                                    toItem: previewView,
                                                    attribute: .top,
                                                    multiplier: 1,
                                                    constant: 0),
                                 NSLayoutConstraint(item: targetView,
                                                    attribute: .centerY,
                                                    relatedBy: .equal,
                                                    toItem: previewView,
                                                    attribute: .centerY,
                                                    multiplier: 1,
                                                    constant: 0)])
            
        } else {
            let label = UILabel()
            label.text = "Preview Unavailable\nPress \"Run My Code\" to preview."
            label.numberOfLines = 0
            label.translatesAutoresizingMaskIntoConstraints = false
            label.textAlignment = .center
            
            previewView.addSubview(label)
            
            view.addConstraints([NSLayoutConstraint(item: label,
                                                    attribute: .leading,
                                                    relatedBy: .greaterThanOrEqual,
                                                    toItem: previewView,
                                                    attribute: .leading,
                                                    multiplier: 1,
                                                    constant: 0),
                                 NSLayoutConstraint(item: label,
                                                    attribute: .centerX,
                                                    relatedBy: .equal,
                                                    toItem: previewView,
                                                    attribute: .centerX,
                                                    multiplier: 1,
                                                    constant: 0),
                                 NSLayoutConstraint(item: label,
                                                    attribute: .top,
                                                    relatedBy: .greaterThanOrEqual,
                                                    toItem: previewView,
                                                    attribute: .top,
                                                    multiplier: 1,
                                                    constant: 0),
                                 NSLayoutConstraint(item: label,
                                                    attribute: .centerY,
                                                    relatedBy: .equal,
                                                    toItem: previewView,
                                                    attribute: .centerY,
                                                    multiplier: 1,
                                                    constant: 0)])
        }
        
        self.previewView = previewView
        self.remainingComponentsTableView = remainingComponentsTableView
        self.taskTitleLabel = taskTitleLabel
    }
    
    func setUpPrompt() {
        let promptView = TKRobotPromptView(with: "You found a torn document in the chest. Using HStacks and VStacks, piece the document together.\n\nNeed help? Click on me and ask a question.", sender: self)
        
        promptView.translatesAutoresizingMaskIntoConstraints = false
        promptView.clipsToBounds = true
        view.addSubview(promptView)
        
        view.addConstraints([NSLayoutConstraint(item: promptView,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leadingMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: promptView,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailingMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: promptView,
                                                attribute: .bottom,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .bottomMargin,
                                                multiplier: 1,
                                                constant: -16)])
        
        self.promptView = promptView
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if isCurrent {
            
            promptView.promptText = "You did it! Wait for a bit and we'll get out of this chest."
            
            Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { (_) in
                // Animate to maybe a 3D scene?
                PlaygroundPage.current.navigateTo(page: .next)
            }
        }
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! RemainingComponentsTableViewCell
        
        cell.setUp()
        cell.previewImage = [UIImage(named: "01"), UIImage(named: "02"), UIImage(named: "03")][indexPath.row]
        cell.isUsed = didUseItem[indexPath.row]
        cell.selectionStyle = .none
        
        return cell
    }
    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = UIHostingController(rootView: VStack {Image("0\(indexPath.row + 1)").resizable().aspectRatio(contentMode: .fit); Text("Tap outside to dismiss").font(.system(size: 16))})
        
        self.present(vc, animated: true)
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    public func setPreview(with targetView: UIView) {
        
        let reference = UIHostingController(rootView: VStack(spacing: 0){
            PieceTwo()
            HStack {
                PieceThree()
                PieceOne()
            }
        }).view!
        reference.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        targetView.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        
        targetView.translatesAutoresizingMaskIntoConstraints = false
        
        self.targetView = targetView
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
