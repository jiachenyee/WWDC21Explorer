//
//  MessageCell.swift
//  BookCore
//
//  Created by JiaChen(: on 16/4/21.
//

import Foundation
import UIKit

protocol MessageManager: UITableViewCell {
    var message: Message! { get set }
}
