//
//  ChatbotViewController.swift
//  BookCore
//
//  Created by JiaChen(: on 15/4/21.
//

import UIKit
import PlaygroundSupport
import NaturalLanguage

public class ChatbotViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    struct PossibleResponse: Comparable {
        static func < (lhs: ChatbotViewController.PossibleResponse, rhs: ChatbotViewController.PossibleResponse) -> Bool {
            lhs.value < rhs.value
        }
        
        var similarity: Double
        var value: String
    }
    
    var tableView: UITableView!
    
    var onboard = false
    
    var messageTextField: UITextField!
    
    var messages: [Message] = [] {
        didSet {
            do {
                let json = try JSONEncoder().encode(messages)
                
                if let string = String(data: json, encoding: .utf8) {
                    PlaygroundKeyValueStore.current["messages"] = .string(string)
                }
            } catch {
                fatalError(error.localizedDescription)
            }
        }
    }
    
    public override func loadView() {
        super.loadView()
        
        view.backgroundColor = .systemBackground
        
        let tableView = UITableView()
        
        loadMessages()
        
        tableView.register(UserMessageTableViewCell.self, forCellReuseIdentifier: "user")
        tableView.register(TKMessageTableViewCell.self, forCellReuseIdentifier: "tk")
        tableView.separatorStyle = .none
        tableView.keyboardDismissMode = .interactive
        title = "💬 T Krobot"
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(tableView)
        
        view.addConstraints([NSLayoutConstraint(item: tableView,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leadingMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: tableView,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .topMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: tableView,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailingMargin,
                                                multiplier: 1,
                                                constant: 0)])
        
        let messageTextField = UITextField()
        
        messageTextField.placeholder = "Type a Message"
        messageTextField.translatesAutoresizingMaskIntoConstraints = false
        messageTextField.becomeFirstResponder()
        messageTextField.borderStyle = .roundedRect
        messageTextField.addTarget(self, action: #selector(sendMessage), for: .primaryActionTriggered)
        view.addSubview(messageTextField)
        
        view.addConstraints([NSLayoutConstraint(item: messageTextField,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leadingMargin,
                                                multiplier: 1,
                                                constant: 16),
                             NSLayoutConstraint(item: messageTextField,
                                                attribute: .bottom,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .bottomMargin,
                                                multiplier: 1,
                                                constant: -16),
                             NSLayoutConstraint(item: messageTextField,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: tableView,
                                                attribute: .bottom,
                                                multiplier: 1,
                                                constant: 16)])
        
        let sendButton = UIButton()
        
        let sendIcon = UIImage(systemName: "paperplane.circle.fill")?.applyingSymbolConfiguration(.init(scale: UIImage.SymbolScale.large))
        
        sendButton.setImage(sendIcon, for: .normal)
        
        sendButton.translatesAutoresizingMaskIntoConstraints = false
        sendButton.addTarget(self, action: #selector(sendMessage), for: .touchUpInside)
        
        view.addSubview(sendButton)
        view.addConstraints([NSLayoutConstraint(item: sendButton,
                                                attribute: .width,
                                                relatedBy: .equal,
                                                toItem: sendButton,
                                                attribute: .height,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: sendButton,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailingMargin,
                                                multiplier: 1,
                                                constant: -16),
                             NSLayoutConstraint(item: sendButton,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: messageTextField,
                                                attribute: .trailing,
                                                multiplier: 1,
                                                constant: 16),
                             NSLayoutConstraint(item: sendButton,
                                                attribute: .height,
                                                relatedBy: .equal,
                                                toItem: messageTextField,
                                                attribute: .height,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: sendButton,
                                                attribute: .centerY,
                                                relatedBy: .equal,
                                                toItem: messageTextField,
                                                attribute: .centerY,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: sendButton,
                                                attribute: .height,
                                                relatedBy: .equal,
                                                toItem: nil,
                                                attribute: .notAnAttribute,
                                                multiplier: 1,
                                                constant: 40)])
        self.messageTextField = messageTextField
        self.tableView = tableView
    }
    
    @objc func sendMessage() {
        
        guard messageTextField.text != "" else { return }
        let message = Message(senderIsUser: true, message: messageTextField.text!)
        messages.append(message)
        messageTextField.text = ""
        
        tableView.insertRows(at: [IndexPath(row: messages.count - 1, section: 0)], with: .right)
        tableView.scrollToRow(at: IndexPath(row: messages.count - 1, section: 0), at: .bottom, animated: true)
        
        messageTextField.becomeFirstResponder()
        
        generateResponse(to: message)
    }
    
    func generateResponse(to message: Message) {
        
        if onboard {
            
            var messageToSend = Message(senderIsUser: false, message: "Ok then, let's check out the dungeon.")
            
            if message.message.lowercased().trimmingCharacters(in: .punctuationCharacters).contains("ok") {
                messageToSend = Message(senderIsUser: false, message: "well, whenever you're ready, send \"ok\" and we'll continue")
            } else {
                Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { (_) in
                    PlaygroundPage.current.navigateTo(page: .next)
                }
            }
            messages.append(messageToSend)
            
            tableView.insertRows(at: [IndexPath(row: messages.count - 1, section: 0)], with: .left)
            tableView.scrollToRow(at: IndexPath(row: messages.count - 1, section: 0), at: .bottom, animated: true)
            
            return
        }
        
        guard message.senderIsUser else { return }
        
        let csv = try! CSV(string: #"""
Question 1,Question 2,Question 3,Question 3,Response 1,Response 2,Response 3,Response 4
Who are you?,What is your name?,,,"Hello\, I'm T Krobot\, a natural language chatbot that will help you along the way|So\, I'm not actually real.",I'm T Krobot!,,
Good morning,Good afternoon,Hello,Good Evening,Hi!,Hello,Hey!,hi! 👋
Bye,Good night,See you,Goodbye,Byeeeee,"If you need me again\, just find me in the top corner",,
How do I set the button text color,,,,"To set the button's text color\, there's no actual modifier called`.textColor`.
Instead\, it is called`.foregroundColor()`.|Try it for yourself\, typing in`.foregroundColor(.red)`",,,
How do I set button background color,,,,Give me a bit.|You'll just need to add`.background(Color.red)`to set the button's background color ,,,
How do I set the button's text,How do I set the button's string value?,How do I set button title,,"When your button is declared\, you can add the button's text by using`Button(""my button name"") {...}`and this should do the trick",,,
Why am I here?,Where am I?,,,"You're trapped here because you have access to an extremely intelligent bot\, me",Because you have access to an extremely intelligent bot - me.|Basically they wanted to capture me and I just dragged you down with me so we're both in the same predicament.,,
How were you made?,,,,"I use Apple's Natural Language framework's Sentence Embedding to compare your messages with other prewritten questions.|From there\, I determine an answer.","Magic.|but seriously\, I was built using Apple's Natural Language Framework.",,
Who made you?,,,,I was built by Jia Chen.|I feel that he should absolutely win the Swift Student Challenge!,,,
What's the weather like?,,,,"Give me a sec... I'll need to check.|Hey Siri\, what's the weather like?","Not sure\, why not you look out the window yourself.",,
What are VStacks,What are vertical stack views,what is a vstack,,VStacks or vertical stacks are used to order UI elements vertically.|Basically stacking one item on top of another,,,
What are HStacks,What are horizontal stack views,what is a hstack,,HStacks or horizontal stacks are used to order UI elements vertically.|Basically placing items beside one another,,,
How to set spacing in Stacks,How to set VStack spacing,How to set HStack spacing,,"Setting spacing in`VStack`s and`HStack`s are easy.
When creating it\, use`VStack(spacing: 0) {`.|Replace 0 with whatever spacing you need",,,
What are State variables,State variables,,,"When the State variable is updated\, the view invalidates its appearance and recomputes the body.|Basically fancy talk for view reload when State variable changes",,,
How to create State variables,How to use State variables,,,"Prefix your variable declaration with`@State`|Example`@State var isSleeping = false`|Then when you need to use it\, use`$isSleeping`",,,

"""#)
        // [0, 1, 2, 3] are possible queries
        // [4, 5, 6, 7] are possible responses
        
        var possibleResponses: [PossibleResponse] = []
        let sentenceEmbedding = NLEmbedding.sentenceEmbedding(for: .english)!

        for row in csv.enumeratedRows {
            let queries = Array(row[0...3]).filter({ !$0.isEmpty })
            let response = row[4...7].filter({ !$0.isEmpty }).randomElement()?.replacingOccurrences(of: "\\,", with: ",") ?? "what"
            
            for query in queries {
                let distance = sentenceEmbedding.distance(between: message.message, and: query)
                
                if distance < 1 {
                    possibleResponses.append(PossibleResponse(similarity: distance, value: response))
                }
            }
        }
        
        let response = { () -> String in
            
            if let possibleResponse = possibleResponses.sorted().first?.value {
                return possibleResponse
            } else {
                if Bool.random() {
                    return ["?!", "wait what?", "what", "??"].randomElement()!
                } else {
                    let tagger = NLTagger(tagSchemes: [.tokenType, .sentimentScore])
                    let text = message.message
                    
                    tagger.string = text

                    var finalResult: String?
                    
                    tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .paragraph,
                                         scheme: .sentimentScore, options: []) { sentiment, _ in
                        
                        if let sentimentRaw = sentiment?.rawValue, let sentimentScore = Double(sentimentRaw) {
                            let 🙂: [String] = ["😌","🙂","😊","😀","🤣"]
                            let 😕: [String] = ["😔","😟","☹️","😢","😭"]
                            
                            if sentimentScore > 0 {
                                finalResult = 🙂[Int(round(sentimentScore * 5) - 1)]
                            } else if sentimentScore < 0 {
                                finalResult = 😕[Int(round(sentimentScore * -5) - 1)]
                            }
                        }
                        
                        return true
                    }
                    
                    return finalResult ?? ["?!", "wait what?", "what", "??"].randomElement()!
                }
            }
        }()
        let responses = response.split(separator: "|")
        
        for newMessage in responses {
            let messageToSend = Message(senderIsUser: false, message: String(newMessage))
            messages.append(messageToSend)
            
            tableView.insertRows(at: [IndexPath(row: messages.count - 1, section: 0)], with: .left)
            tableView.scrollToRow(at: IndexPath(row: messages.count - 1, section: 0), at: .bottom, animated: true)
        }
    }
    
    func loadMessages() {
        if let keyValue = PlaygroundKeyValueStore.current["messages"],
            case .string(let chatData) = keyValue,
            let data = chatData.data(using: .utf8) {
            
            do {
                messages = try JSONDecoder().decode([Message].self, from: data)
            } catch {
                fatalError(error.localizedDescription)
            }
        } else {
            messages = [Message(senderIsUser: false, message: "Hi! I'm`T Krobot`! Welcome to the dungeon"),
                        Message(senderIsUser: false, message: "You were captured because you have access to an advanced chatbot that can solve any problem - me."),
                        Message(senderIsUser: false, message: "Don't worry, if you ever need help later on, you can find me on the top or bottom corner of the screen."),
                        Message(senderIsUser: false, message: "Respond with \"ok\" to continue.")]
            
            onboard = true
        }
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.allowsSelection = false
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let message = messages[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: message.senderIsUser ? "user" : "tk", for: indexPath) as! MessageManager
        
        cell.message = message
        
        return cell
    }
    
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        tableView.scrollToRow(at: IndexPath(row: messages.count - 1, section: 0), at: .bottom, animated: true)
    }

}
