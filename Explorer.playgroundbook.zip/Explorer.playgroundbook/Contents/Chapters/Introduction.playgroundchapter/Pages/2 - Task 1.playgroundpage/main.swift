//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import SwiftUI
import PlaygroundSupport
import BookCore
//#-end-hidden-code
//: ````
//:   __,                    ,   , ____
//:  (           o  /) _/_  /   /   /
//:   `.  , , , ,  //  /   /   /;  /
//: (___)(_(_/_(_ //_ (__ (___/ (_‘__
//:              /)
//:             (/
//: ````
//: # Task 1: Unlock the Chest
//: In the Live View on the right, there are 2 rows of 3 buttons.
//: - The first row is a reference
//: - The second row is a set of buttons that you should make identical to the first
//:
//: > The colors used in the reference (first row) are `Color.orange`
//: ### Button 1
//: > Press Run My Code and see your changes on the live view.
//#-hidden-code
//#-observe-0
let firstButton =
//#-end-hidden-code
Button(/*#-editable-code*/"SwiftUI"/*#-end-editable-code*/) {
}
//#-editable-code
//#-end-editable-code
//#-hidden-code
//#-end-observe-0
//#-end-hidden-code
//: ### Button 2
//: > Press Run My Code and see your changes on the live view.
//#-hidden-code
//#-observe-1
let secondButton =
//#-end-hidden-code
Button(/*#-editable-code*/"is"/*#-end-editable-code*/) {
}
//#-editable-code
//#-end-editable-code
//#-hidden-code
//#-end-observe-1
//#-end-hidden-code
//: ### Button 3
//: > Press Run My Code and see your changes on the live view.
//#-hidden-code
//#-observe-2
let thirdButton =
//#-end-hidden-code
Button(/*#-editable-code*/"Great!"/*#-end-editable-code*/) {
}
//#-editable-code
//#-end-editable-code
//#-hidden-code
//#-end-observe-2
//#-end-hidden-code
//#-hidden-code
func initialize() {
    let vc = TaskOneViewController()
    
    vc.buttonOneView = UIHostingController(rootView: firstButton).view!
    vc.buttonTwoView = UIHostingController(rootView: secondButton).view!
    vc.buttonThreeView = UIHostingController(rootView: thirdButton).view!
    
    PlaygroundPage.current.liveView = vc
}

initialize()
//#-end-hidden-code
